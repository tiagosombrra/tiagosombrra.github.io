package br.edu.unifametro;

public class ContaBancaria {
	
	private float saldo;
	
	public ContaBancaria(float saldo) {
		this.saldo = saldo;
	}

	public float getSaldo() {
		return saldo;
	}
	
	public boolean deposito (float deposito) {
		if (deposito > 0) {
			saldo += deposito;
			return true;
		} else {
			return false;
		}
	}
	public boolean saque(float saque) {
		if (saque > saldo) {
			return false;
		}else {
			saldo -= saque;
			return true;
		}
	}
}
