package br.edu.unifametro;

import java.util.ArrayList;
import java.util.Scanner;

public class Exec {

	public static void main(String[] args) {
		
		ArrayList<Sala> salas = new ArrayList<Sala>();
		Sala sala1 = new Sala(30);
		Sala sala2 = new Sala(20);
		
		salas.add(sala1);
		salas.add(sala2);
		
		sala1.alocacao();
		sala1.getAlocacao();	
		
		sala2.alocacao();
		sala2.getAlocacao();	

		
	/*	Conta bancaria
	 * 
	 * 
	 * String operacao;
		
		ContaBancaria cb = new ContaBancaria(0.0f);
		System.out.println("Valor instanciado: "+cb.getSaldo());
		
		do {
			System.out.println("Digite a opera��o que deseja efetuar:");
			Scanner operacaoIn = new Scanner(System.in);
			operacao = operacaoIn.next();
			
			if (operacao.equals("saque")) {
				System.out.println("Digite o valor que deseja sacar: ");
				float valor;
				valor = operacaoIn.nextFloat();
				boolean condicao = cb.saque(valor);
				if (condicao) {
					System.out.println("Saque efetuado: "+cb.getSaldo());
				}else {
					System.out.println("Saque n�o efetuado");

				}
			}else if (operacao.equals("deposito")) {
				System.out.println("Digite o valor que deseja depositar: ");
				float valor;
				valor = operacaoIn.nextFloat();
				boolean condicao = cb.deposito(valor);
				if (condicao) {
					System.out.println("Deposito efetuado: "+cb.getSaldo());
				}else {
					System.out.println("Deposito n�o efetuado");

				}
			}else {
				System.out.println("Opera��o Inv�lida.");
			}
		} while (true);
		*/		
	}
}
