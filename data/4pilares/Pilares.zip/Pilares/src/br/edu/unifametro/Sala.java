package br.edu.unifametro;

public class Sala {
	
	private boolean alocacao;
	private int capacidade;

	public Sala(int capacidade) {
		this.capacidade = capacidade;
	}
	
	public boolean alocacao() {
		if (!alocacao) {
			alocacao = true;
			return true;
		}else {
			return false;
		}
	}
	
	public boolean desalocar() {
		if (alocacao) {
			alocacao = false;
			return true;
		}else {
			return false;
		}
	}
	
	public void getAlocacao() {
		if (alocacao) {
			System.out.println("Sala alocada");
		}else {
			System.out.println("Sala desalocada");

		}
	}
}
